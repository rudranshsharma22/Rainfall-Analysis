--------------------
API
--------------------

Main Function
--------------------

.. autoclass:: idf_analysis.idf_class.IntensityDurationFrequencyAnalyse
    :members:
    :no-undoc-members:
